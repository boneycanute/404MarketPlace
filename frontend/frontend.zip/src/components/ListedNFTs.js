import React, { useState, useEffect } from 'react';
import { useWeb3 } from './ConnectWallet';
import NFTMarketplaceABI from '../contracts/NFTMarketplace.json'; // Import the ABI of your NFTMarketplace contract
import { Container, CardMedia, Grid, Card, CardContent, Link, Typography, Box } from '@mui/material';
import CircularProgress from '@mui/material/CircularProgress';

function ListedNFTs() {
    const { web3js, marketplaceContract, connected } = useWeb3();

    const [nftListings, setNftListings] = useState([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (connected) {
            fetchListings();
        }
    }, [connected]);

    const fetchListings = async () => {
        try {
            setLoading(true);
            const allListings = await marketplaceContract.methods.allListings().call();
            console.log(allListings);
            const listingsWithDetails = await Promise.all(
                allListings.map(async (address) => {
                    const NFTInstance = new web3js.eth.Contract(NFTMarketplaceABI, address);
                    const URI = await getURI(NFTInstance);
                    const name = await getName(NFTInstance);
                    return { nftAddress: address, URI, name };
                })
            );
            setNftListings(listingsWithDetails);
            setLoading(false);
        } catch (error) {
            console.error('Error fetching listings:', error);
        }
    };

    const getURI = async (NFTInstance) => {
        const URI = await NFTInstance.methods.tokenURI().call();
        const response = await fetch(URI);
        const metadata = await response.json();
        return metadata.image;
    };

    const getName = async (NFTInstance) => {
        const name = await NFTInstance.methods.name().call();
        return name;
    };

    return (
        <Container maxWidth="md">
            <Typography variant="overline" fontSize={40}>All NFTs listed</Typography>
            {connected ? (
                loading ? (
                    <Box>
                        <CircularProgress />
                    </Box>
                ) : nftListings.length > 0 ? (
                    <Grid container spacing={2}>
                        {nftListings.map((listing, index) => (
                            <Grid item xs={12} sm={6} md={4} key={index}>
                                <Link href={`https://nftmarketplace-a.vercel.app/${listing.nftAddress}`} style={{ textDecoration: 'none', color: 'inherit' }}>
                                    <Card sx={{ '&:hover': { boxShadow: '0px 0px 10px 0px rgba(0,0,0,0.3)', cursor: 'pointer' } }}>
                                        <CardMedia
                                            component="img"
                                            height="200"
                                            image={listing.URI}
                                            alt={`NFT ${index}`}
                                        />
                                        <CardContent sx={{ alignItems: "center", justifyContent: "center", textAlign: "center" }}>
                                            <Typography variant="h5">{listing.name}</Typography>
                                        </CardContent>
                                    </Card>
                                </Link>
                            </Grid>
                        ))}
                    </Grid>
                ) : (
                    <p>No NFT minted</p>
                )
            ) : (
                <p>Connect your wallet to continue</p>
            )}
        </Container>
    );
}

export default ListedNFTs;
